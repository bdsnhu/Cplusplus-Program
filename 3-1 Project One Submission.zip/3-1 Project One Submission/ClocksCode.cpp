/*
* ClocksCode.cpp
*
Date: 09-14-2022
Author: Ben Douglas
*/

#include <iostream>
#include <iomanip>
#include <string> //I used string for ampm.

using namespace std;
int hour12, hour24, minute, second;
string ampm;
void addOneHour() { //I used this to add a Hour.
    hour12 = hour12 + 1;
    //after adding set the clock accordingly
    if (hour12 >= 12) {
        hour12 = hour12 - 12;
        if (ampm == "AM") //I used this for AM on the Clock.
            ampm = "PM"; //I used this for PM on the Clock.
        else
            ampm = "AM";
    }
}

void addOneMin() { //I used this to add a Minute.
    minute = minute + 1;
    //after adding set the clock accordingly
    if (minute > 59) {
        minute = 0;
        addOneHour();
    }
}

void addOneSec() { //I used this to add a Second.
    second = second + 1;
    //after adding set the clock accordingly
    if (second > 59) {
        second = 0;
        addOneMin();
    }
}


void displayMenu()
{ //I used this to display the solution Menu.
    cout << "**************************" << endl;
    cout << "* 1-Add One Hour         *" << endl;
    cout << "" << endl;
    cout << "* 2-Add One Minute       *" << endl;
    cout << "" << endl;
    cout << "* 3-Add One Second       *" << endl;
    cout << "" << endl;
    cout << "*4-Exit Program          *" << endl;
    cout << "**************************" << endl;
}

int main() {

    int userinput;
    hour12 = 4; //I used this to manually set the Hour that I have on my computer. 
    minute = 44; //I used this to manually set the Minute that I have on my computer.
    second = 24; //I used this to manually set the Second that I have on my computer.
    ampm = "PM"; //Iused this to manually set AM or PM that I have on my computer.
    while (1) { //I used this for my while loop.
        if (ampm == "PM") { //I used this for PM.
            hour24 = hour12 + 12;
            if (hour24 >= 24) {
                hour24 = hour24 - 24;
            }
        }
        else {
            hour24 = hour12;
        }
        cout << "**************************     **************************" << endl; //I used lines 76-80 to output both Clocks.
        cout << "*       12-Hour Clock    *     *       24-Hour Clock    *" << endl;
        cout << "*        " << setw(2) << setfill('0') << hour12 << ":" << setw(2) << setfill('0') << minute << ":" << setw(2) << setfill('0') << second << " " << ampm << "   ";
        cout << "\t *     *         " << setw(2) << setfill('0') << hour24 << ":" << setw(2) << setfill('0') << minute << ":" << setw(2) << setfill('0') << second << " " << "      *\n";
        cout << "**************************     **************************" << endl;
        displayMenu();
        cout << "Enter a option" << endl; //I used this so the user can enter a option on the menu.
        cin >> userinput;
        if (userinput == 1) {
            addOneHour(); //I used this to add one Hour on the Clocks.
        }
        else if (userinput == 2) {
            addOneMin(); //I used this to add one Minute on the Clocks.
        }
        else if (userinput == 3) {
            addOneSec(); //I used this to add one Second on the Clocks.
        }
        else if (userinput == 4) {
            break; //I used this to Exit the Program.
        }
        else
            cout << "Invalid input!"; //I used this to let the user know if they put a invalid input into the menu, like 0 or 5.
    }
    return 0;
}